# Bratva Bot
Bot Discord pentru tickete de muncă în FiveM.
